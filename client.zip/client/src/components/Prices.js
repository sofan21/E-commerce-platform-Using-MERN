export const Prices = [
  {
    _id: 0,
    name: "500 to 4,999 ETB",
    array: [0, 19],
  },
  {
    _id: 1,
    name: "5,000 to 9,999 ETB",
    array: [20, 39],
  },
  {
    _id: 2,
    name: "10,000 to 49,999 ETB",
    array: [40, 59],
  },
  {
    _id: 3,
    name: "50,000 to 99,999 ETB",
    array: [60, 79],
  },
  {
    _id: 4,
    name: "100,000 to 199,999 ETB",
    array: [80, 99],
  },
  {
    _id: 5,
    name: "200,000 or more",
    array: [100, 9999],
  },
];
